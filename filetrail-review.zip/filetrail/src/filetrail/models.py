from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
from typing import Any

# How much a source is trusted when several disagree. Higher wins.
CONFIDENCE = {
    "browser-download": 90,
    "windows-zone-identifier": 85,
    "macos-wherefroms": 85,
    "xdg-xattr": 80,
    "archive-member": 70,
    # A purpose-built provenance standard, but the signature is not verified here.
    "c2pa": 60,
    "device-metadata": 55,
    "document-metadata": 50,
    "shell-history": 40,
    # An application opening a file proves contact, not acquisition.
    "recent-documents": 35,
    "filesystem": 10,
}

#: How each source reads in prose. Data about sources, so it lives beside the
#: confidence table rather than in the renderer - reconciliation needs to name a
#: source too, and importing the renderer to do it would be a cycle.
SOURCE_LABELS = {
    "browser-download": "browser download",
    "windows-zone-identifier": "Windows zone",
    "macos-wherefroms": "macOS where-from",
    "xdg-xattr": "XDG attribute",
    "archive-member": "archive member",
    "c2pa": "content credentials",
    "device-metadata": "device metadata",
    "document-metadata": "document metadata",
    "shell-history": "shell history",
    "recent-documents": "recent documents",
    "filesystem": "filesystem",
}

#: Commands that plausibly fetch a file. Kept here rather than in the shell
#: reader because deciding what kind of claim an origin makes is a question
#: about sources, and the reader imports this module rather than the reverse.
FETCH_TOOLS = frozenset(
    {
        "curl",
        "wget",
        "aria2c",
        "yt-dlp",
        "youtube-dl",
        "git",
        "scp",
        "rsync",
        "s3cmd",
        "aws",
        "gh",
        "gallery-dl",
        "wpull",
        "httrack",
        "monolith",
    }
)

#: How the file reached this machine. Another system wrote it down at the time.
ACQUISITION = "acquisition"

#: Something on this machine handled the file afterwards. It proves contact and
#: says nothing about where the bytes came from - an application opening a file
#: did not put it there, and presenting the two as one kind of claim invites
#: exactly that misreading.
INTERACTION = "interaction"

#: What the file records about its own earlier life: who made it, with what,
#: when and where. It travelled with the bytes.
INTRINSIC = "intrinsic"

_KINDS = {
    "browser-download": ACQUISITION,
    "windows-zone-identifier": ACQUISITION,
    "macos-wherefroms": ACQUISITION,
    "xdg-xattr": ACQUISITION,
    "archive-member": ACQUISITION,
    "filesystem": ACQUISITION,
    "recent-documents": INTERACTION,
    "c2pa": INTRINSIC,
    "device-metadata": INTRINSIC,
    "document-metadata": INTRINSIC,
}


def kind(origin: Origin) -> str:
    """Which of the three questions this claim answers.

    Shell history is the one source that answers either, and which one is
    already in the record: `curl -o` fetched the bytes, `cat` merely touched
    them. Deciding per origin rather than per source keeps a `cat` from being
    reported as though it explained where a file came from.
    """
    if origin.source == "shell-history":
        return ACQUISITION if (origin.tool or "") in FETCH_TOOLS else INTERACTION
    return _KINDS.get(origin.source, INTERACTION)


@dataclass(slots=True)
class Origin:
    """One claim about where a file came from, made by one source."""

    source: str
    url: str | None = None
    referrer: str | None = None
    tool: str | None = None
    command: str | None = None
    at: str | None = None
    location: str | None = None
    bytes: int | None = None
    mime: str | None = None
    sha256: str | None = None
    note: str | None = None

    #: Everything the reader decoded, named rather than numbered, beyond the
    #: handful of fields the report summarises. An investigation cannot know in
    #: advance which one matters, so nothing decoded is thrown away.
    fields: dict[str, str] = field(default_factory=dict)

    @property
    def confidence(self) -> int:
        return CONFIDENCE.get(self.source, 0)

    def redacted(self) -> Origin:
        """Return a copy with credentials removed from every free-text field."""
        from .redact import redact_text, redact_url

        def clean(value: str) -> str:
            # A tag like UserComment is free text: it can hold a URL, a command
            # or a bare token, so it goes through both sweeps.
            return redact_url(redact_text(value))

        return replace(
            self,
            url=clean(self.url) if self.url else None,
            referrer=clean(self.referrer) if self.referrer else None,
            command=redact_text(self.command) if self.command else None,
            fields={name: clean(value) for name, value in self.fields.items()},
        )

    def to_dict(self) -> dict[str, Any]:
        data = {k: v for k, v in asdict(self).items() if v}
        data["confidence"] = self.confidence
        return data


@dataclass(slots=True)
class FileRecord:
    """Everything known about one file on disk."""

    path: str
    size: int
    mtime: str
    btime: str | None = None
    sha256: str | None = None
    origins: list[Origin] = field(default_factory=list)

    @property
    def best(self) -> Origin | None:
        """The single strongest claim, whatever kind it is.

        Used for grouping and counting, where one file needs one answer. It is
        not what the report prints: see `acquisition` and `intrinsic`.
        """
        if not self.origins:
            return None
        return max(self.origins, key=lambda o: (o.confidence, o.at or ""))

    @property
    def acquisition(self) -> Origin | None:
        """The strongest claim about how the file got here."""
        return self._strongest(ACQUISITION)

    @property
    def interaction(self) -> Origin | None:
        """The strongest claim that something here handled the file."""
        return self._strongest(INTERACTION)

    @property
    def intrinsic(self) -> Origin | None:
        """The strongest claim the file makes about its own earlier life.

        Kept apart from `acquisition` because they answer different questions.
        Ranking them against each other lets a download record delete a camera's
        GPS fix, which is the more valuable of the two far more often than not.
        """
        return self._strongest(INTRINSIC)

    def _strongest(self, wanted: str) -> Origin | None:
        candidates = [origin for origin in self.origins if kind(origin) == wanted]
        if not candidates:
            return None
        return max(candidates, key=lambda o: (o.confidence, o.at or ""))

    def redacted(self) -> FileRecord:
        return replace(self, origins=[origin.redacted() for origin in self.origins])

    def to_dict(self) -> dict[str, Any]:
        return {
            "path": self.path,
            "size": self.size,
            "mtime": self.mtime,
            "btime": self.btime,
            "sha256": self.sha256,
            "origins": [o.to_dict() for o in self.origins],
        }
